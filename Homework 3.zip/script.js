let send1 =  {"info": "With Habitat, we had the mission of building houses of different types.",
              "img" : "habitat.jfif",
              "cap" : "House Mid-Build",
              "head" : "Habitat"            };
document.getElementById("a1").innerHTML = send1.info;
document.getElementById("h1").innerHTML = send1.head;
//document.getElementById("c1").textContent = send1.cap;
document.getElementById("i1").src = send1.img;

let send2 = {"info" : "With Catholic Heart Work Camp, we had the mission of building a new handicap rap for an iconic baseball field.",
             "img" : "chwc.jpg",
             "head" : "Catholic Heart Work Camp"};
document.getElementById("a2").innerHTML = send2.info;
document.getElementById("h2").innerHTML = send2.head;
document.getElementById("i2").src = send2.img;

let send3 = {"info" : "As far as mechanics, I have worked on variety of mechanisms as a kid.",
             "img" : "mechanic.jfif",
             "head" : "Mechanics"}
document.getElementById("a3").innerHTML = send3.info;
document.getElementById("h3").innerHTML = send3.head;
document.getElementById("i3").src = send3.img;

let send4 = {"info" : "Since I was around 5 years old, I have been taking apart devices, studying the insides, repairing, and putting them back together.",
             "img" : "pc.jfif",
             "head" : "Computer Building/Repair"}
document.getElementById("a4").innerHTML = send4.info;
document.getElementById("h4").innerHTML = send4.head;
document.getElementById("i4").src = send4.img;